from flask import Flask
from AppContent import app
from AppContent.dataBaseConfig import Config
from AppContent.dataBaseConfig import ClientConfig

Config.db.create_all()