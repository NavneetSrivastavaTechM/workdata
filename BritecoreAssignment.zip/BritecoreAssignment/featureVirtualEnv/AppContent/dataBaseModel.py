from AppContent import app 
from flask_sqlalchemy import SQLAlchemy
from AppContent.dataBaseConfig import Config, ClientConfig


class DataBaseModel(Config.db.Model):

    __tablename__ = Config.tableName
    title = Config.db.Column(Config.db.String(30),primary_key=True)
    description = Config.db.Column(Config.db.String(300))
    client = Config.db.Column(Config.db.String(30))
    clientPriority = Config.db.Column(Config.db.Integer)
    targetDate = Config.db.Column(Config.db.Date)
    productArea = Config.db.Column(Config.db.String(30))

    def __init__(self,title,description,client,clientPriority,targetDate,productArea):
        self.title = title
        self.description = description
        self.client = client
        self.clientPriority = clientPriority
        self.targetDate = targetDate
        self.productArea = productArea


class DataBaseClientDetails(ClientConfig.db.Model):

    __tablename__ = ClientConfig.tableName
    category = ClientConfig.db.Column(ClientConfig.db.String(20))
    value = ClientConfig.db.Column(ClientConfig.db.String(20), primary_key=True, unique=True)
    
    def __init__(self,category,value):
        self.category = category
        self.value = value
