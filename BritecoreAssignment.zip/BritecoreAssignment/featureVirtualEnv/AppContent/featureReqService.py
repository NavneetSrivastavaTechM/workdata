from AppContent.dataBaseConfig import Config, ClientConfig
from AppContent.dataBaseModel import DataBaseModel, DataBaseClientDetails
from sqlalchemy.exc import *

class FeatureReqService:

    def __init__(self):
        self.session= ''

    def setSession(self, argSession):
        self.session= argSession

    def getSession(self):
        if self.session == '': 
            self.session= Config.db.session
            return self.session            
        else:            
            return self.session

    def DataBaseInsertion(self,formValues):
       
            clientPriorityService = int(formValues.clientPriority)
            totalClientPriDetails =len(self.getSession().query(DataBaseModel).filter_by(client=formValues.client).all())
            print(totalClientPriDetails)
            clientType = formValues.client
            if clientPriorityService <= totalClientPriDetails:
                print("inside service insertion if")
                self.RepriotizationLogic(clientPriorityService,totalClientPriDetails,clientType)
                self.getSession().add(formValues)
                self.getSession().commit()
            else:
                print("inside service insertion else")
                self.getSession().add(formValues)
                self.getSession().commit()

    def RepriotizationLogic(self,clientPriorityService,totalClientPriDetails,clientType):

            print("coming in repriortization logic")
            for clientPriorityService in range(clientPriorityService,totalClientPriDetails+1,1):
                (self.getSession().query(DataBaseModel).filter_by(clientPriority=clientPriorityService, client = clientType).first()).clientPriority+=1
                self.getSession().commit()
                self.getSession().close()
        

    def DataBaserRetrieval(self):
        
            rowValues= DataBaseModel.query.all()
            totaldetails=[]
            
            for rowVal in rowValues:
                extData ={}

                extData['title'] = rowVal.title
                extData['description'] = rowVal.description
                extData['client'] = rowVal.client
                extData['clientPriority'] = rowVal.clientPriority
                extData['targetDate'] = rowVal.targetDate
                extData['productArea'] = rowVal.productArea

                totaldetails.append(extData)
            return totaldetails

    def DataBaseClientValues(self):
        
            clientValues = DataBaseClientDetails.query.all()
            totalClientdetails = []

            for clientVal in clientValues:
                extClientData = {}

                extClientData['category'] = clientVal.category
                extClientData['value'] = clientVal.value

                totalClientdetails.append(extClientData)
            return totalClientdetails

    def DataBaseFetchDetails(self,title_name):

            rowVal = DataBaseModel.query.filter_by(title=title_name).first()
            
            editVal={}

            editVal['title'] = rowVal.title
            editVal['description'] = rowVal.description
            editVal['client'] = rowVal.client
            editVal['clientPriority'] = rowVal.clientPriority
            editVal['targetDate'] = rowVal.targetDate
            editVal['productArea'] = rowVal.productArea
            return editVal

    def DataBaseDeleteDetails(self,title_name):

            print("fetch in services delete row logic")
            deleteData=self.getSession().delete(DataBaseModel.query.delete().filter_by(title=title_name).all())
            print("deleeeeeeeeeeeee : "+deleteData)
            return "success"

            


