from AppContent.featureReqService import FeatureReqService
from AppContent.dataBaseModel import DataBaseModel
from flask import  request, jsonify
from AppContent import app


class FeatureRequestManager:

    @app.route('/generateDetails', methods=['POST'])
    def setDetails():
        service = FeatureReqService()
        service.DataBaseInsertion(DataBaseModel(request.json['title'],request.json['description'],request.json['client'],request.json['clientPriority'],request.json['targetDate'],request.json['productArea']))
        return "success"

    @app.route('/showDetails', methods=['GET'])
    def GetDetails():
        req = FeatureReqService()
        row = req.DataBaserRetrieval()
        return jsonify({'rowValues':row})

    @app.route('/getBasicClientData', methods=['GET'])
    def ClientBasicData():
        clientData = FeatureReqService()
        row = clientData.DataBaseClientValues()
        return jsonify({'clientValues': row})
    
    @app.route('/fetchDetails', methods=['POST'])
    def FetchDetails():
        print("fetch in manager")
        editDetails = FeatureReqService()
        editRow=editDetails.DataBaseFetchDetails(request.json['title'])
        return jsonify({'editValues': editRow})

    @app.route('/deleteDetails', methods=['POST'])
    def DeleteDetails():
        print("fetch in manager delete")
        deleteDetails = FeatureReqService()
        deleteDetails.DataBaseDeleteDetails(request.json['title'])
        return "success"
        
 
    

    
