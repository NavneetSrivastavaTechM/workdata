from AppContent import app
from flask_sqlalchemy import SQLAlchemy

class ClientConfig:
    app.config['SQLALCHEMY_DATABASE_URI']='mysql://root:Password0$@localhost:3306/featuresdb'
    db = SQLAlchemy(app)
    tableName = 'ClientDataTable'

class Config:
    app.config['SQLALCHEMY_DATABASE_URI']='mysql://root:Password0$@localhost:3306/featuresdb'
    db = SQLAlchemy(app)
    tableName = 'FeatureRequestTable'

 