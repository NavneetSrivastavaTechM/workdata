from flask import Flask
from flask import render_template
from AppContent import app

@app.route("/")
def home():
    return render_template('formRequest.html')

@app.route("/request")
def request():
    return render_template('featureRequestInputs.html')

@app.route("/details")
def details():
    return render_template('displayFeaturesTable.html')