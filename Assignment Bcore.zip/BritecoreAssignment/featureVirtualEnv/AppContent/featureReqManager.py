from AppContent.featureReqService import FeatureReqService
from AppContent.dataBaseModel import DataBaseModel
from flask import  request, jsonify
from AppContent import app


class FeatureRequestManager:

    @app.route('/generateDetails', methods=['POST'])
    def setDetails():
        print("coming in generate")
        service = FeatureReqService()
        service.DataBaseInsertion(DataBaseModel(request.json['title'],request.json['description'],request.json['client'],request.json['clientPriority'],request.json['targetDate'],request.json['productArea']))
        return "success"

    @app.route('/showDetails', methods=['GET'])
    def GetDetails():
        req = FeatureReqService()
        row = req.DataBaserRetrieval()
        return jsonify({'rowValues':row})

    @app.route('/getBasicClientData', methods=['GET'])
    def ClientBasicData():
        print("fetching client manager")
        clientData = FeatureReqService()
        row = clientData.DataBaseClientValues()
        return jsonify({'clientValues': row})
        
 
    

    
