from flask import Flask

app = Flask(__name__)

from AppContent import dataBaseConfig, dataBaseModel, featureReqManager, featureReqService, routing