from AppContent.dataBaseConfig import Config, ClientConfig
from AppContent.dataBaseModel import DataBaseModel, DataBaseClientDetails
from sqlalchemy.exc import *

class FeatureReqService:

    def __init__(self):
        self.session= ''

    def setSession(self, argSession):
        self.session= argSession

    def getSession(self):
        if self.session == '': 
            self.session= Config.db.session
            return self.session            
        else:            
            return self.session

    def DataBaseInsertion(self,formValues):
       
            clientPriorityService = int(formValues.clientPriority)
            totalClientPriDetails =len(self.getSession().query(DataBaseModel).filter_by(client=formValues.client).all())
            clientType = formValues.client
            if clientPriorityService <= totalClientPriDetails:
                print("inside service insertion if")
                self.RepriotizationLogic(clientPriorityService,totalClientPriDetails,clientType)
                self.getSession().add(formValues)
                self.getSession().commit()
            else:
                print("inside service insertion else")
                self.getSession().add(formValues)
                self.getSession().commit()

    def RepriotizationLogic(self,clientPriorityService,totalClientPriDetails,clientType):

            print("coming in repritization logic")
            for clientPriorityService in range(clientPriorityService,totalClientPriDetails+1,1):
                (self.getSession().query(DataBaseModel).filter_by(clientPriority=clientPriorityService, client = clientType).first()).clientPriority+=1
                self.getSession().commit()
                self.getSession().close()
        

    def DataBaserRetrieval(self):
        try:
            rowValues= DataBaseModel.query.all()
            totaldetails=[]
            
            for rowVal in rowValues:
                extData ={}

                extData['title'] = rowVal.title
                extData['description'] = rowVal.description
                extData['client'] = rowVal.client
                extData['clientPriority'] = rowVal.clientPriority
                extData['targetDate'] = rowVal.targetDate
                extData['productArea'] = rowVal.productArea

                totaldetails.append(extData)
            return totaldetails

        except Exception as e:
            print("Error Occured in Retrieval",e)
            return 'Error Occured'

    def DataBaseClientValues(self):
        try:
            print("fetching client service")
            clientValues = DataBaseClientDetails.query.all()
            totalClientdetails = []

            for clientVal in clientValues:
                extClientData = {}

                extClientData['category'] = clientVal.category
                extClientData['value'] = clientVal.value

                totalClientdetails.append(extClientData)
            return totalClientdetails

        except Exception as e:
            print("Error Occured in ClientDataRetrieval",e)
            return 'Error Occured'


